package com.project.controller;

import java.text.ParseException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.dtos.DaywiseOrderDto;
import com.project.dtos.DtoEntityConverter;
import com.project.dtos.Response;
import com.project.entities.DaywiseOrder;
import com.project.services.DaywiseOrderService;

@CrossOrigin(origins = "*")
@RestController
public class DaywiseOrderController {

	@Autowired
private	DaywiseOrderService daywiseOrderService;
	
	@Autowired
	private DtoEntityConverter converter;
	
	@GetMapping("/daywiseOrder/{id}")
	public ResponseEntity<?> displayDaywiseOrders(@PathVariable("id") int id) {
		DaywiseOrderDto daywiseOrderDto = daywiseOrderService.findByDoId(id);
		return Response.success(daywiseOrderDto);
	}

@PostMapping("/daywiseOrder/addOrder")
public ResponseEntity<?> Addorder(@RequestBody DaywiseOrderDto daywiseorder){
	
	DaywiseOrderDto daywiseOrderdto=daywiseOrderService.addDaywise(daywiseorder);
	return Response.success(daywiseOrderdto);
	
}
@PostMapping("/daywiseOrder/addallorders")
public ResponseEntity<?> Addall(){
	return Response.success(daywiseOrderService.addDaywiseOrder());
}
}
