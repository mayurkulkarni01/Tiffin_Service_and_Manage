package com.project.daos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.entities.DaywiseOrder;

public interface DaywiseOrderDao extends JpaRepository<DaywiseOrder, Integer>{
	

	DaywiseOrder findByDoId(int doId);


}
