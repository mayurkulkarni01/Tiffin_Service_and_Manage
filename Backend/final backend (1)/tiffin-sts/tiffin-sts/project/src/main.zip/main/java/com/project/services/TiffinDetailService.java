package com.project.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.project.daos.TiffinDetailDao;
import com.project.dtos.DtoEntityConverter;
import com.project.dtos.TiffinDetailDto;
import com.project.entities.TiffinDetail;

@Transactional
@Service
public class TiffinDetailService {
	@Autowired
	private TiffinDetailDao tiffinDetailDao;
	@Autowired
	private DtoEntityConverter converter;
	
	public TiffinDetailDto findOrderById(int tiffinId) {
		TiffinDetail tiffinDetail = tiffinDetailDao.findByTiffinId(tiffinId);
		return converter.toTiffinDetailDto(tiffinDetail);
	}
}
