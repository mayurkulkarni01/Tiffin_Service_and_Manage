package com.project.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.project.daos.UserDao;
import com.project.dtos.Credential;
import com.project.dtos.DtoEntityConverter;
import com.project.dtos.UserDto;
import com.project.entities.User;

@Transactional
@Service
public class UserService {

	@Autowired
	private UserDao userDao;
	@Autowired
	private DtoEntityConverter converter;
	@Autowired
	private PasswordEncoder passwardencoder;
	public UserDto findUserById(int userId) {
		User user = userDao.findByUserId(userId);
		return converter.toUserDto(user);
	}
	
	public UserDto findUserByEmail(String email) {
		User user = userDao.findByEmail(email);
		return converter.toUserDto(user);
	}
	public UserDto findUserByEmailAndPassword(Credential cred) {
		User user=userDao.findByEmail(cred.getEmail());
		String rawpassword=cred.getPassword();
		System.out.println(cred);
		if(user!=null && passwardencoder.matches(rawpassword ,user.getPassword())) {
			return converter.toUserDto(user);
		}
		return null;
	}
	public UserDto AddUser(User user) {
		String rawpassword=user.getPassword();
		String encrpassword=passwardencoder.encode(rawpassword);
		user.setPassword(encrpassword);
		userDao.save(user);
		return converter.toUserDto(user);
	}
}
