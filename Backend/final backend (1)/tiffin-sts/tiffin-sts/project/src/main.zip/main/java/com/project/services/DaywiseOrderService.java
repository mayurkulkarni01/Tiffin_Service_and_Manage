package com.project.services;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.daos.DaywiseOrderDao;
import com.project.daos.OrderDao;
import com.project.dtos.DaywiseOrderDto;
import com.project.dtos.DtoEntityConverter;
import com.project.dtos.OrderDto;
import com.project.entities.DaywiseOrder;
import com.project.entities.Order;
import com.project.entities.User;

@Service
@Transactional
public class DaywiseOrderService {

	@Autowired
	DaywiseOrderDao daywiseOrderDao;
	@Autowired
	DtoEntityConverter converter;
	@Autowired
	private OrderDao orderdao;

	public DaywiseOrderDto findByDoId(int doId) {
		DaywiseOrder dayWiseOrder = daywiseOrderDao.findByDoId(doId);
		System.out.println(converter.toDaywiseOrderDto(dayWiseOrder));
		return converter.toDaywiseOrderDto(dayWiseOrder);
	}
public DaywiseOrderDto addDaywise(DaywiseOrderDto daywiseorderDto) {
	DaywiseOrder daywiseOrder=converter.dayWiseOrderDTOtoDayWiseOrder(daywiseorderDto);
	daywiseOrderDao.save(daywiseOrder);
	return converter.toDaywiseOrderDto(daywiseOrder);
}
public List<DaywiseOrderDto> addDaywiseOrder(){
	List<Order> orders=orderdao.findAll();
	List<DaywiseOrder> daywiselist=new ArrayList<DaywiseOrder>();
	List<DaywiseOrderDto> daywisedtolist=new ArrayList<DaywiseOrderDto>();
	for(Order o:orders) {
		//int doId, Date date, String session, int requirement, String status, Order order,
		//User deliveryBoy
		Date date=new Date();  
		System.out.println(o.getEndDate()+ "  +  "+date.getHours() );
		if(o.getEndDate().compareTo(date)>=1) {
			daywiseOrderDao.deleteAll();
			if(date.getHours()<12) {
		DaywiseOrder ox=new DaywiseOrder(o.getEndDate(),"morning",1,"plain",new Order(o.getOrderId()),o.getUser());
		daywiselist.add(ox) ;
		daywisedtolist.add(converter.toDaywiseOrderDto(ox));
			}
			else {
				DaywiseOrder ox=new DaywiseOrder(o.getEndDate(),"night",1,"plain",new Order(o.getOrderId()),o.getUser());
				daywiselist.add(ox) ;
				daywisedtolist.add(converter.toDaywiseOrderDto(ox));
			}
		}
	}
	daywiseOrderDao.saveAll(daywiselist);
	return daywisedtolist;
}

}
