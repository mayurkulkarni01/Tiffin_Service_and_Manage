package com.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.project.dtos.Response;
import com.project.dtos.TiffinDetailDto;
import com.project.services.TiffinDetailService;

@CrossOrigin(origins = "*")
@RestController
public class TiffinDetailController {

	@Autowired
	private TiffinDetailService tiffinDetailService;
	
	@GetMapping("/tiffinDetail/{id}")
	public ResponseEntity<?> displayTiffinDetail(@PathVariable("id") int id) {
		TiffinDetailDto tiffinDetailDto = tiffinDetailService.findOrderById(id);
		return Response.success(tiffinDetailDto);
	}
}
