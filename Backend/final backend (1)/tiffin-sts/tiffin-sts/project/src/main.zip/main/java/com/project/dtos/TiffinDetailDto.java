package com.project.dtos;

import java.sql.Blob;

public class TiffinDetailDto {

	private int tiffinId;
	private String tiffinName;
	private Blob tiffinImage;
	private int tiffinPrice;
	private String desription;
	
	public TiffinDetailDto() {
		// TODO Auto-generated constructor stub
	}

	public TiffinDetailDto(int tiffinId, String tiffinName, Blob tiffinImage, int tiffinPrice, String desription) {
		super();
		this.tiffinId = tiffinId;
		this.tiffinName = tiffinName;
		this.tiffinImage = tiffinImage;
		this.tiffinPrice = tiffinPrice;
		this.desription = desription;
	}

	public int getTiffinId() {
		return tiffinId;
	}

	public void setTiffinId(int tiffinId) {
		this.tiffinId = tiffinId;
	}

	public String getTiffinName() {
		return tiffinName;
	}

	public void setTiffinName(String tiffinName) {
		this.tiffinName = tiffinName;
	}

	public Blob getTiffinImage() {
		return tiffinImage;
	}

	public void setTiffinImage(Blob tiffinImage) {
		this.tiffinImage = tiffinImage;
	}

	public int getTiffinPrice() {
		return tiffinPrice;
	}

	public void setTiffinPrice(int tiffinPrice) {
		this.tiffinPrice = tiffinPrice;
	}

	public String getDesription() {
		return desription;
	}

	public void setDesription(String desription) {
		this.desription = desription;
	}

	@Override
	public String toString() {
		return "TiffinDetailsDto [tiffinId=" + tiffinId + ", tiffinName=" + tiffinName + ", tiffinImage=" + tiffinImage
				+ ", tiffinPrice=" + tiffinPrice + ", desription=" + desription + "]";
	}
}
